# Changelog
## v001 (2026-10-13)
First release, modeled on plot writing kit v004's startup and handback rules. Includes the snapshot (341 tasks), almanac plus its dependencies, check.py, make-patch.py, task-preview.py (unencrypted monolithic Sight HTML), the ground truth survey input, and examples. Versions are plain integers: the next one is v002, never dotted.
