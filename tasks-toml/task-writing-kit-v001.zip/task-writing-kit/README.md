# Task writing kit v001

A kit for proposing new tasks and task changes as a patch against a frozen copy of tasks.toml. You never edit a live file. You return a patch, and the user and the reviewer go through it together.

## Start here
1. Read this whole kit before doing anything: README.md, task-spec.md (section 0 first), context-brief.md, policies.md, rubric.md, examples/, and every file in inputs/. Read every file in full; skimming is not allowed.
2. Once you've read it all, send ONE short message: ask whether to break `inputs/260710-001-ground-truth-survey.md` down into a task patch now, or whether there are other files or requests. Then wait.
3. If the next message is files with no text, that is the go signal. Treat them as the inputs to turn into tasks and follow the kit without asking anything first. If the reply is a plain yes to the survey, go ahead on the survey.

## Layout
- `snapshot/tasks.toml`: the frozen base. `snapshot/SHA256` holds its hash. Never edit it.
- `tools/scripts/almanac.tcl`, plus `cli.tcl`, `tama.tcl`, `tools/lib/tosu/tama.tcl`, and `tools/deps/tcl` (Tcl 9 zipkit, linux-x64; system `tclsh` 8.6 also works).
- `check.py`: the gate. Run it until it reports 0 FAIL.
- `make-patch.py`: writes tasks.patch from your working copy.
- `task-preview.py`: renders one self-contained, unencrypted Sight HTML file for the snapshot with or without your patch.
- `skin/`: Sight CSS, board.js, template and fonts. These are used by the preview.
- `inputs/`: the source material (the ground truth survey).
- `examples/`: a passing patch and changes note.

## Workflow
```
chmod +x tools/deps/tcl                      # some unzip tools drop the exec bit
(cd snapshot && sha256sum -c SHA256)         # confirm the base
mkdir -p work && cp snapshot/tasks.toml work/tasks.toml
export ALMANAC_SKIP_BOARD_EXPORT=1          # required: stops almanac from rebuilding the live board
ALM="tools/deps/tcl tools/scripts/almanac.tcl --file work/tasks.toml"   # or: tclsh tools/scripts/almanac.tcl ...
$ALM add title="Title" status=later domain=CTP notes='...'
$ALM set <id> status=today
$ALM done <id>
$ALM validate
python3 make-patch.py                        # -> tasks.patch (or: diff -u snapshot/tasks.toml work/tasks.toml)
python3 check.py tasks.patch --changes changes.md --coverage coverage.md
python3 task-preview.py tasks.patch -o preview.html   # optional, for your own review
```
Run `$ALM` with no arguments to see its usage. If the flag spelling differs on your copy, follow the usage it prints. Always point it at work/tasks.toml, never at a live path.

## Handback
Attach in chat:
- `tasks.patch`: a unified diff against snapshot/tasks.toml.
- `changes.md`: one line per touched task, `id  new|changed|done  why`.
- `coverage.md`: required when the work came from an input document such as the survey.
Also include check.py's summary line. Never commit, push, or copy anything into a live tree.

## Preview
`python3 task-preview.py` with no patch renders the snapshot. With a patch, it marks touched cards (green for new, amber for changed, violet for done; done cards show under the done filter) and puts a field-by-field review panel at the top. The output is a single HTML file with no network access and no encryption.
