# changes (example)
tz57  done     meeting cancellation was sent, so the reminder is closed
80d5  changed  gave it the FIN domain and the Nov 3 date it already names in its title
mcd7  new      the Resolve backup method depends on the database type, which is still unknown
8zg9  new      first bottom line is the one concrete ITAA step left open
