# Examples
`tasks.patch` and `changes.md` were made with almanac on a copy of the snapshot: two adds, one set, and one done. They pass:
    python3 check.py examples/tasks.patch --changes examples/changes.md
Preview: `python3 task-preview.py examples/tasks.patch -o /tmp/ex.html`.
The ids mcd7 and 8zg9 were allocated at build time. Your own run will get different ones.
