#!/usr/bin/env python3
"""Write tasks.patch: a unified diff of work/tasks.toml against snapshot/tasks.toml.
Usage: python3 make-patch.py [work/tasks.toml] [tasks.patch]
Same output shape as: diff -u snapshot/tasks.toml work/tasks.toml > tasks.patch
Stdlib only."""
import difflib, os, sys
kit = os.path.dirname(os.path.abspath(__file__))
work = sys.argv[1] if len(sys.argv) > 1 else 'work/tasks.toml'
outp = sys.argv[2] if len(sys.argv) > 2 else 'tasks.patch'
a = open(os.path.join(kit, 'snapshot', 'tasks.toml'), encoding='utf-8').read().splitlines(keepends=True)
b = open(work, encoding='utf-8').read().splitlines(keepends=True)
d = ''.join(difflib.unified_diff(a, b, 'snapshot/tasks.toml', 'work/tasks.toml', n=3))
if not d: sys.exit('make-patch: no changes')
open(outp, 'w', encoding='utf-8').write(d)
print(f'make-patch: wrote {outp} ({d.count(chr(10))} lines)')
