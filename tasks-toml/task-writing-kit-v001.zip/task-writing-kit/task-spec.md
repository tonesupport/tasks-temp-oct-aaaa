# Task spec v001

## 0. Run rules
- Read every kit file and every input in full before you start. In coverage.md, write `read X of Y bytes` for each input.
- Files that arrive with no text are the go signal. Proceed without asking.
- After startup, offer to break `inputs/260710-001-ground-truth-survey.md` down into a task patch. Use the same handback rules as for any other input.
- Work only on a copy (work/tasks.toml). Never edit snapshot/, and never touch live files or repos. Never commit or push.
- Return only tasks.patch, changes.md, and coverage.md (for document inputs). check.py must report 0 FAIL first.

## 1. File format
tasks.toml is TOML with one `[<id>]` table per task. The `root` / spine section at the top is structure. Don't change it unless the user asks.

Required keys: `title`, `status`, `created`, `updated`, `tags`.
Optional keys: `domain` (HH MED CTP FIN DEV, or the others in use), `project`, `notes`, `datetime`, `time`, `duration`, `completed`, `blockers`, `reminder`, `signaling-command`, `coordinating-agents`, `field_links`, `tosu`.
Forbidden: `content`.

## 2. Statuses
`urgent now progress today later deferred sched done`
- `done` needs `completed`. Use `almanac done <id>`.
- `sched` needs `datetime`.
- `duration` only on now, done, or sched.
- `datetime` format is `Ddd Mmm D YY`, for example `Tue Nov 3 26`.

## 3. Stamps
`created`, `updated`, and `completed` are 10-digit integers, YYMMDDhhmm in America/Los_Angeles. Almanac sets them. Never change `created`. `updated` goes up on every change.

## 4. Tags
- Write tags as a single-quoted TOML array, for example `tags = ['task','acct']`.
- Every task must have the tag `'task'`, never `'tasks'`.
- Almanac adds `'tosu'` for personal domains (HH MED CTP FIN DEV). Don't add other tags that the input doesn't support.

## 5. IDs
IDs are random `[a-z0-9]{4}` and only almanac allocates them (`almanac add`). Never pass `id=` to add, and never pick, guess, reuse, or make a mnemonic for one. Never renumber existing IDs.

## 6. Titles and wording
- One concrete action or fact per title, in plain, neutral words.
- No master-plan codes (inf3, rep2, shd1, …), no IDs, and no code prefixes in titles.
- Specs and task text never name agents. Describe the work, not who does it.
- Notes give context needed to act, written factually. No hype and no speculation unless it's labeled.

## 7. Editing
- Use almanac verbs (add, set, done). Hand-edit only when almanac can't make the change, and say so in the why column of changes.md.
- Never delete a task. To close one, mark it done. If a task looks obsolete, propose it in changes.md as `done` with the reason.
- Blockers must name existing IDs and never the task itself.

## 8. Breaking down a document (the survey)
- Go through it section by section. Before adding anything, search the snapshot for an existing task that covers each item (`almanac ls`, grep). If one exists, change it or map it as `exists: id`; don't add a duplicate.
- The survey dates from July 2026. Items that have already happened, or are superseded, are `dropped: stale (reason)`.
- `{{...}}` annotations are the user's own notes. They take priority over the text around them.
- coverage.md has one row per section: `section -> id, id`, or `exists: id`, or `dropped: reason`, then a line `read X of Y bytes`.

## 9. changes.md
One line per touched task: `id  new|changed|done  why`. The why is one short clause. check.py checks that every id in the patch has a line and that each line matches the patch.

## 10. Patch
A unified diff of exactly one file, with the snapshot as the base (`--- a/tasks.toml`, `+++ b/tasks.toml`). It must apply cleanly with no fuzz.
